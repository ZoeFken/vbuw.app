</section>
<footer class="footer page-footer font-small pt-4 text-center mt-auto bg-primary text-white">
	<p>Unieke code &copy; Casteels Pieter-Jan <?php echo date("Y") ?></p>
	<a href="#"><?php echo $this->lang->line('name_site'); ?></a></p>
</footer>
</main>
<script src="<?php echo base_url('assets/js/bootstrap.min.js'); ?>"></script>
</body>
</html>
