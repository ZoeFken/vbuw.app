<html>
<head>
    <title>Contact aanvraag Fotografie Sandy</title>
</head>
<body>
    <table width="100%" border="0" cellspacing="0" cellpadding="0">
        <tr>
            <td align="left">
                <h1>Beste,</h1>
                <p>Er is een nieuw contact aanvraag verstuurd</p>
                <p><b>De naam:</b> <?php echo $name; ?></p>
                <p><b>Het email adres:</b> <?php echo $email; ?></p>
                <p><b>Het bericht:</b> <br><?php echo $message; ?></p>
            </td>
        </tr>
    </table>
</body>
</html>