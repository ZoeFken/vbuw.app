<h2 class="display-4 text-center pb-3">Applicatie procedure</h2>

<section>
	<p>Deze tool is in ontwikkeling wilt U deze tool testen en deelnemen aan de beta? Contacteer dan <span class="text-success">Pieter-Jan Casteels</span>.<br>
	U moet voldoen aan enkele eisen:</p>
	<ol>
		<li>Medewerker zijn van tucrail</li>
		<li>De tool gebruiken</li>
		<li>Feedback geven voor verbetering</li>
	</ol>
	<p class="text-danger">Ik behoud het recht iedereen op welk moment dan ook te verwijderen van het systeem.</p>
	<p>Eens de aanvraag ontvangen is zal ik u toegang verlenen aan het systeem. Ik maak een account aan waarna U een link krijgt om uw eigen paswoord aan te maken. 
	Ikzelf heb geen zicht op welk paswoord U aanmaakt en deze paswoorden worden geincripteerd in de database. 
	Wel raad ik U aan een ander paswoord te gebruiken dan uw standaard paswoord. Dit is en blijft een beta versie.<p>
	<p class="text-center">Op dit moment nog geen contact formulier dus mail me vanuit je tucrail mailbox<br>
	<span class="text-success">pieter-jan.casteels@tucrail.be</span></p>
</section>
