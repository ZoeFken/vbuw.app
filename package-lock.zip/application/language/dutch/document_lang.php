<?php
defined('BASEPATH') OR exit('No direct script access allowed');

$lang["aangemaakt"] = "Aangemaakt";
$lang["opgemaaktDoor"] = "Opgemaakt door";
$lang["type"] = "Type";
$lang["titel"] = "Bestanden";
$lang["download_s460"] = "Download S 460";
$lang["aantal_dagen"] = "Aantal dagen";
$lang["tussen_dagen"] = "tussen 0 en 8";
$lang["datum_aanvang"] = "Datum aanvang";
$lang["wissel"] = "Wissel verzender - ontvanger";
$lang["download"] = "Download";
$lang["editeer"] = "Editeer";
