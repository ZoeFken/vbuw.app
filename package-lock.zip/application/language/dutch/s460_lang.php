<?php
defined('BASEPATH') OR exit('No direct script access allowed');

// Invul doc
$lang["titel"] = "Opmaak S 460";
$lang["melding"] = "Melding";
$lang["verzender"] = "verz"; //verzender
$lang["ontvanger"] = "ontv"; //ontvanger
$lang["voeg_meer_toe"] = "Voeg meer toe";
$lang["submit"] = "Verzender";
