<?php
defined('BASEPATH') OR exit('No direct script access allowed');

// Voorbeeld
$lang["log_110"] = "Voorbeeld log code";
