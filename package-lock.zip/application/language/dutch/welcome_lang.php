<?php
defined('BASEPATH') OR exit('No direct script access allowed');

$lang["welkom"] = "Welkom";
$lang["docVersion"] = "VBUW Document generator v0.75";
$lang["text_1"] = "Deze tool is nog in ontwikkeling. Gelieve elke fout door te geven aan.";
$lang["creator"] = "Casteels Pieter-Jan";
$lang["reglementering"] = "Onthoud aub dat deze tool de reglementering niet vervangt. U blijft ten alle tijden verantwoordelijk voor wat je doet op de werven.";
$lang["melding"] = "Voor het veelvuldig aanmaken van documenten tegen te gaan heb ik een limiet ingesteld van 10 documenten per persoon. U kan ten alle tijden een document verwijderen of aanpassen. Dit kan in de toekomst herzien worden aan de hand van het gebruik door iedereen.";
