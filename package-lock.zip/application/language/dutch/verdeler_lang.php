<?php
defined('BASEPATH') OR exit('No direct script access allowed');

// Invul
$lang["titel"] = "Opmaak verdeler";
$lang["ingediendDoor"] = "Ingediend Door";
$lang["bnx"] = "BNX";
$lang["aanvangsDatum"] = "Aanvangs datum";
$lang["aanvangUur"] = "Aanvang uur";
$lang["eindDatum"] = "Eind datum";
$lang["eindUur"] = "Eind uur";
$lang["lijn"] = "Lijn";
$lang["spoor"] = "Spoor";
$lang["kpVan"] = "KP van";
$lang["kpTot"] = "KP tot";
$lang["tpo"] = "TPO - F.B.S.S";
$lang["gevallen"] = "Gevallen";
$lang["uiterstePalen"] = "Uiterste punten";
$lang["geplaatstePalen"] = "Locatie geplaatste SSV";

// Uitleg
$lang["documentNaam"] = "voor document naam";
$lang["uurNotatie"] = "uur notatie 12:30";
$lang["datumNotatie"] = "datum notatie 25-01-2020";
