<?php
defined('BASEPATH') OR exit('No direct script access allowed');

$lang["form_validation_valid_date"] = "Dit is geen geldige datum";
$lang["form_validation_valid_hours_minutes"] = "Uur notatie moet HH:MM zijn!";
