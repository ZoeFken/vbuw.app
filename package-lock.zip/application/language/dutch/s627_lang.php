<?php
defined('BASEPATH') OR exit('No direct script access allowed');

// Invul doc
$lang["titel"] = "Opmaak S 627";
$lang["ingediendDoor"] = "Ingediend Door";
$lang["specialiteit"] = "Specialiteit";
$lang["aan"] = "Aan";
$lang["post"] = "Post / Werf";
$lang["station"] = "Station";
$lang["aanvraag"] = "Aanvraag";
$lang["vermoedelijkeDuur"] = "Vermoedelijke duur";
$lang["rubriek2ARMS"] = "Rubriek 2A RMS";
$lang["rubriek2AAndere"] = "Rubriek 2A Andere";
$lang["rubriek5VVHW"] = "Voltooiing van het werk";
$lang["aanvangDatum"] = "Aanvang datum";
$lang["aanvangUur"] = "Aanvang uur";
$lang["eindDatum"] = "Eind datum";
$lang["eindUur"] = "Eind uur";

// Uitleg
$lang["uurNotatie"] = "uur notatie 12:30";
$lang["datumNotatie"] = "datum notatie 25-01-2020";
