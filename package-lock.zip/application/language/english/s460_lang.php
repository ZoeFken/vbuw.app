<?php
defined('BASEPATH') OR exit('No direct script access allowed');

// Invul doc
$lang["titel"] = "Create S 460";
$lang["melding"] = "Message";
$lang["verzender"] = "Sender";
$lang["ontvanger"] = "Reciever";
$lang["voeg_meer_toe"] = "Add more";
$lang["submit"] = "Submit";
