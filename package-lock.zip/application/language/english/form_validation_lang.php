<?php
defined('BASEPATH') OR exit('No direct script access allowed');

$lang["form_validation_valid_date"] = "This is not a valid date";
$lang["form_validation_valid_hours_minutes"] = "Time notation should be HH:MM!";
