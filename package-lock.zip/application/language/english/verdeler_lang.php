<?php
defined('BASEPATH') OR exit('No direct script access allowed');

// Invul
$lang["titel"] = "Create verdeler";
$lang["ingediendDoor"] = "Submitted by";
$lang["bnx"] = "BNX";
$lang["aanvangsDatum"] = "Starting date";
$lang["aanvangUur"] = "Starting hour";
$lang["eindDatum"] = "End date";
$lang["eindUur"] = "End hour";
$lang["lijn"] = "Line";
$lang["spoor"] = "Track";
$lang["kpVan"] = "KP from";
$lang["kpTot"] = "KP to";
$lang["tpo"] = "TPO - F.B.S.S";
$lang["gevallen"] = "Sections";
$lang["uiterstePalen"] = "End poles";
$lang["geplaatstePalen"] = "Location of placed SSV";

// Uitleg
$lang["documentNaam"] = "for document name";
$lang["uurNotatie"] = "hour notation 12:30";
$lang["datumNotatie"] = "date notation 25-01-2020";
