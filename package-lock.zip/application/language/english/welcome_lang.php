<?php
defined('BASEPATH') OR exit('No direct script access allowed');

$lang["welkom"] = "Welcome";
$lang["docVersion"] = "VBUW Document generator v0.75";
$lang["text_1"] = "This tool is stil in development. If you find a bug please inform me.";
$lang["creator"] = "Casteels Pieter-Jan";
$lang["reglementering"] = "Please remember that this tool will never exceed the regulations! You will always stay liable for what you do at the job!";
$lang["melding"] = "Curent document limit of 10 for every person. You can always edit or delete a document if needed. This can be changed after a look at the current overal use.";
