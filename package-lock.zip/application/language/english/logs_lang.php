<?php
defined('BASEPATH') OR exit('No direct script access allowed');

// Example
$lang["log_110"] = "Example log code";
