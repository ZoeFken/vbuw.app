<?php
defined('BASEPATH') OR exit('No direct script access allowed');

$lang["aangemaakt"] = "Created";
$lang["opgemaaktDoor"] = "Constructed by";
$lang["type"] = "Type";
$lang["titel"] = "Files";
$lang["download_s460"] = "Download S 460";
$lang["aantal_dagen"] = "Ammount of days";
$lang["tussen_dagen"] = "between 0 and 8";
$lang["datum_aanvang"] = "Start date";
$lang["wissel"] = "Switch sender - reciever";
$lang["download"] = "Download";
$lang["editeer"] = "Edit";
