<?php
defined('BASEPATH') OR exit('No direct script access allowed');

$lang["titel"] = "VBUW Document Generator";
$lang["home"] = "Home";
$lang["s627"] = "S 627";
$lang["s460"] = "S 460";
$lang["verdeler"] = "Verdeler";
$lang["i427"] = "I 427";
$lang["doc"] = "Documents";
$lang["persoonlijk"] = "Personel";
$lang["alle"] = "All";
$lang["blanco"] = "Blanco";
$lang["gebruikers"] = "Users";

$lang["login"] = "Login";
$lang["logout"] = "Logout";
$lang["register"] = "Register";
$lang["edit"] = "Edit User";
