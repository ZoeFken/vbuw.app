<?php
defined('BASEPATH') OR exit('No direct script access allowed');

// Invul doc
$lang["titel"] = "Create S 627";
$lang["ingediendDoor"] = "Submitted by";
$lang["specialiteit"] = "Speciality ";
$lang["aan"] = "To";
$lang["post"] = "Post / Wharf";
$lang["station"] = "Station";
$lang["aanvraag"] = "Request";
$lang["vermoedelijkeDuur"] = "Likly duration";
$lang["rubriek2ARMS"] = "Rubriek 2A RMS";
$lang["rubriek2AAndere"] = "Rubriek 2A Other";
$lang["rubriek5VVHW"] = "Finishing of the job";
$lang["aanvangDatum"] = "Starting date";
$lang["aanvangUur"] = "Starting time";
$lang["eindDatum"] = "End date";
$lang["eindUur"] = "End time";

// Uitleg
$lang["uurNotatie"] = "hour notation 12:30";
$lang["datumNotatie"] = "date notation 25-01-2020";
