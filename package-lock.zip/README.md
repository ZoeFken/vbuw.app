# VBUW.APP

Een applicatie gemaakt voor het automatiseren van dagelijkse documenten nodig bij het buitendienststelen of buitenspanningstelling van een spoor. 

## Gebruik

Op dit moment kan de tool gebruikt worden via vbuw.app
Hiervoor is wel een login nodig, deze kan aangevraagd worden via de site.

## Installation

Uploaden van de folders op je webdomein 
```
exlcude backup
exclude user_guide
```
Voer de DB querry uit in je phpmyadmin
```
folder backup->db->laastedatum.sql
```
Je kan dit ook allemaal in een lokale omgeving gebruiken hiervoor raadt ik xammp aan.

## Contributing
Elke toevoeging is welkom

## License
[GNU AGPLv3](https://choosealicense.com/licenses/agpl-3.0/)
